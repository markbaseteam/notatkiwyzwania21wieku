[[Wykład 1 - artukuł 1#Bezpieczeństwo/zagrożenie ekologiczne (wyzwanie)|Bezpieczeństwo ekologiczne]] jest elementem bezpieczeństwa międzynarodowego, który zapewnia ochronę żywotnych interesów społeczeństwa ludzkiego, środowiska naturalnego i stanów rzeczywistych lub potencjalnych zagrożeń stwarzanych przez sztuczne lub naturalne środowisko.

W jego skład bezpieczeństwa narodowego -> ekologicznego wchodzi [[Wykład 3 - artykuł 3 - Brak wody pitnej jako zagrożenie dla bezpieczeństwa ekologicznego i polityki żywnościowej|brak wody pitnej jako zagrożenie dla bezpieczeństwa ekologicznego i polityki żywnościowej]] 

# Brak wody pitnej

**Problem dostępu do wody jest niezwykle istotny z powodów:**
 - Woda jest jednym z czynników produkcji w wielu przemysłach i jest wymagana aby życie przetrwało. 
 - 1/8 mieszkańców Ziemi cierpi z powodu braku wody pitnej 
 - 1/8 mieszkańców Ziemi cierpi z powodu chorób wywołanych spożywaniem zanieczyszczonej wody
 - 2,6 mld osób żyje w złych warunkach sanitarnych (Brak wody)
 - brak wody i słabe warunki sanitarne oznaczają śmierć - głównie mieszkańcy Afryki i Azji
 - codziennie umiera około 2 000 dzieci poniżej 5 roku życia z powodu zatrucia (złe warunki sanitarne + woda)
 - zapotrzebowanie na wodę rośnie (więcej ludzi większe zagregowane potrzeby, jest także czynnikiem produkcji)
 - 80% wody pochłania rolnictwo
 - tylko 1% całej wody słodkiej na ziemi jest możliwa do wykorzystania 
 - ocieplenie klimatu powoduje brak wody pitnej
 - degradacja zbiorników wodnych
 - poziomy wód podziemnych się obniżają 
 - lodowce z wodą pitna topnieją
 - skażenie wody pitnej 


**Co może spowodować brak wody pitnej**
 - naciski polityczne
 - zwiększenie cen żywności
 - migracje
 - konflikty różnego rodzaju i o różnej skali (państwowe, lokalne)
 - szantaże i terroryzm 
 - spowolnienie wzrostu gospodarczego lub jego zanik czy nawet kurczenie się gospodarki
 - zmniejszenie jakości życia społeczeństwa

**Rozwiązania**
 - poprawa jakości wód słodkich (oczyszczanie)
 - przepisy regulacyjne np. ramowa dyrektywa wodna, oczyszczania ścieków komunalnych i wody pitnej
 - Współpraca państw i instytucji międzynarodowych
 - Inicjatywy podobne do niebieskiej gospodarki, niebieskiego wzrostu i [Europejski Zielony ład](https://commission.europa.eu/strategy-and-policy/priorities-2019-2024/european-green-deal_pl)
 - zwiększenie rentowności przemysłu odnawialnych surowców np. dotacje itp.
 - edukacja ludzi na temat braku wody aby ograniczyć jej marnowanie
 - kampanie mające na celu zmniejszenie zużycie wody
 - współpraca wszystkich społeczeństw, rządów i instytucji


![[Artykul-do-zajec-z-przedmiotu----Glowne-wyzwania-XXI-wieku - Wykład 3.docx]]