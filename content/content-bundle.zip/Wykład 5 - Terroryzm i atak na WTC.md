Przyczyny
 - fanatyzm islamski


Atak na WTC spowodował **skutki** uboczne:
 - zagrożenie bezpieczeństwa nierodowitych mieszkańców ameryki
 - zamknięcia muzumańskich szkół
 - rozwój kultury odmiennych kultur jak 
 - zablokowanie obyczajów mniejszości narodowych
 - olbrzymie straty materialny
	 - koszty towarzystw ubezpieczeniowych
	 - koszty reasekuracyjne
	 - koszty linii lotniczych
	 - spadek obrotów branży turystycznej (zmniejszenie pobytu na loty samolotem)
	 - zniszczenie World trade Center 
	 - destabilizacja systemu finansowego (ratowanie sytuacji)
 - podwyższenie stawek ubezpieczeniowych
 - spadek cen biletów lotniczych
 - upadłość firm lotniczych
 - spadek cen produktów luksusowych
 - śmierć pasażerów
 - śmierć strażaków ratujących ludzi w budynkach 
 - śmierć innych służb na rzecz pomocy ofiarom ataku
 - wojna z Irakiem
 - wojna z Afganistanem - podbicie Afganistanu przez USA 
 - Osamy bin Ladena
 - rozwój służba w CIA & FBI w USA
 - rozwój wojska w USA w tym przeciwdziałanie terroryzmowi 
 - rozwój bezpieczeństwa na lotniskach (zaostrzenie kontroli)
 - rozwój bezpieczeństwa w sektorze publicznym
 - zaostrzenie kontroli na granicach
 - pogwałcenie praw człowieka, prywatności obywateli i wolności.
 - reforma służb specjalnych

**Rozwiązania**:
 - współpraca międzynarodowa
	 - rozwiązywanie napięć i konfliktów miedzy-narodowych
	 - szybkie rozwiązywanie  problemów


![[Artykul_nt_ataku_terrorystycznego_z_11_wrzesnia_2001_roku_na_USA - Wykład 5.pdf]]