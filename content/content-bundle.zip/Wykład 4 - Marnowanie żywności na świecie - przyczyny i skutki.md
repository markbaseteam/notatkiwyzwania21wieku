
 - 925 milionów osób zagrożone jest niedożywieniem.
 - rocznie stratom ulega 1.3 mln ton żywności, która mogłaby zostać spożyta
 - w Unii marnuje się około 179 kg na osobę 
 - 79 milionów osób żyje poniżej progu ubóstwa
 - zaprzestanie marnowania żywności i  redystrybucja zaspokoiło by głód około 47.4 mln osób
 - należy rozpatrywać ten problem jako globalny

**Przyczyny ogólne**
 - ubytki naturalne (susze, złe warunki przechowywania)
 - straty (produkcja rolnicza, zbiory, przetwórstwo, transport, magazynowanie)
 - marnotrawco jedzenia
 - wyrzucanie jedzenie bliskie końca terminu przydatności
 - niewłaściwe praktyki
 - brak poszanowania żywności
 - nadprodukcja
 - brak zaawansowanych technik rolnych
 - niedostatecznie rozwinięta infrastruktura transportu 
 - nieodpowiednie przechowywanie
 - fałszowanie autentyczności żywności 
 - fałszowanie dat na żywności 
 - nieodpowiednie kampanie marketingowe żywności (np. błędne określenie grupy docelowej produktu)
 - masowa utylizacja żywności
 - brak wiedzy na temat instytucji odbierających niepotrzebną  żywność np. Federacja Polskich Banków żywności)

**Przyczyny po stronie konsumenta**
 - wyrzucanie żywności o zbliżającym się ku końcowi bądź przekroczonym terminie przydatności do spożycia (terminy często są nieprawdziwe)
 - niska jakość wielu produktów
 - niedostateczne programy edukacyjne
 - nieświadomość konsumentów odnośnie skali problemu marnotrawstwa żywności
 - nieracjonalne zakupy
 - brak wiedzy o właściwym sposobie przechowywania produktów spożywczych
 - nieodpowiednie porcjowanie żywności podczas przygotowywania posiłków (zbyt duże porcje)
 - nieracjonalne przyrządzanie posiłków
 - łatwy dostęp do produktów spożywczych

**Skutki**
 - społeczne
 - ekonomiczne
 - ekologiczne
 - nadkonsumpcja
 - utylizacja żywności powoduje zanieczyszczenie środowiska, wpływ na ocieplenie klimatu i straty wody

**Rozwiązania**
 - wspólne inicjatywy zmniejszające marnotrawstwo żywności na poziomie krajowym, europejskim i światowym
 - uświadamianie ludności
 - poszerzanie wiedzy na temat marnowania żywności i wpływu na środowisko
 - redystrybucja żywności 
 - zrównoważona konsumpcja - Zrównoważona konsumpcja wpływa na wzrost dobrobytu oraz równość społeczną, równocześnie zmniejszając zużycia zasobów naturalnych
 - inicjatywy podobne do FAO (oszczędzaj żywność)
 - redukcja odpadów żywności
 - programy międzynarodowe 
 - przekazywanie żywności na cele charytatywne
 - ograniczenie konsumpcji

![[Artykul-do-zajec-z-przedmiotu----Glowne-wyzwania-XXI-wieku - Wykład 3 i 4.docx]]