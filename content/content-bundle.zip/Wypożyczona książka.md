### Osłabianie się Europy
Powody:
 - Kryzys finansowo-gospodarczy
 - Wspólna waluta
 - Uchodźcy 
 - Ataki terrorystyczne
 - Brexit (Odejście Wielkiej Brytanii  UE)
 - Kryzys polityczny i Gospodarczy

**Rozwiązanie**
 - Nowy przywódca, lider z wizją, który by poprowadził Europę w dobrą stronę
 - Zmiana systemu politycznego, jego modernizacja
 - według Fishera aby Europa zachowała integralność potrzebuje również iść w kierunku pro społecznej lekko socjalistycznej Europy i odchodzić od neoliberalizmu
 - zmienić politykę oszczędności
 - zwiększyć skalę inwestycji w państwach rozwijających się, słabo rozwiniętych i będących w kryzysie
 - zwiększenie demokracji w Unii Europejskiej 