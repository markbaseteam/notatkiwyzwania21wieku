Jakie są przesłanki i istota migracji we współczesnym świecie oraz kim są jej uczestnicy – migranci ?

## Wyzwanie XXI wieku - Migracje

**Migracja** nie jest zjawiskiem nowym. Jest znana od dziejów. Ludzie migrują aby zapewnić lepsze warunki bytowe i schronienie. 

Powody migracji
	- Dobrowolne
		- zła sytuacja ekonomiczna
			- brak pracy, pespektyw życiowych
			- bieda
		- konflikty międzynarodowe, wojny
		- zła sytuacja polityczna
		- klęski i katastrofy 
	- Przymusowe
		- deportacje
		- przesiedlenia

Skutki migracji
 - Pozytywne
	- rozwój cywilizacyjny (wzrost  gospodarczy, rozwój ekonomiczny włącznie)
		- wymiana kulturowa
		- wymiana handlowa
		- wymiana genetyczna (chyba nie najlepiej mieć mieszańców, RASOWA CZYSTA EUROPA :D)
	- zapełnienie niżu demograficznego
 - Negatywne
	 - wzrost terroryzmu
	 - nowe przestępstwa
	 - wzrost przestępczości zorganizowanej
	 - większe bezrobocie/tania siła robocza (nowe osoby migrujące zabierają pracę rodowitym obywatelom)
	 - problem z integracją społeczeństwa
	 - zacieranie się kultur
	 - zanik odrębności kulturowych
	 - porzucanie swojego majątku, rodziny i przyjaciół


Przykład
   - Polacy po rozbiorach i utracie niepodległości 
   - migranci z Syrii 
   - migranci z Iraku
   - migranci z Afganistanu
   - migranci z Sudanu 
   - migranci z Azji
   - migranci z Afryki

**Rozwiązania**
 - rozwiązania globalne czyli solidarność
 - współpraca państw
 - współpraca państw z **organizacjami międzynarodowymi** np. ONZ, UE, Rada Europy
 - współpraca instytucji rządowych i pozarządowych 
 - regulacje międzynarodowe 
 - ograniczyć prawem migracje + kontrola na granicach krajów
 - poprawa warunków życia w państwie z którego ludzie emigrują
 - budowa muru jak USA za czasów Donalda Trumpa
 - edukacja migrantów i rodowitych obywateli aby polepszyć integrację 
 - pomoc finansowa migrantom (godziwe warunki do życia np. edukacja)
 - pomoc urzędów (np. praca dla migrantów, nauka nowego jeżyka dla migrantów)
 - zakończenie wojen w krajach z, których emigrują ludzie 
 - zakończenie głodu w państwach, które mają słabe warunki bytowe i zarobkowe (może redystrybucja żywności by coś pomogła)
 - odbudować zniszczone miasta po wojnach

![[Wykład II - Moj-artykul-na-temat-migracji.pdf]]