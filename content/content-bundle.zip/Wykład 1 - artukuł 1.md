**Globalizacja** - oznacza zwiększanie współzależności i integracji państw, społeczeństw, gospodarek i kultur czyli tworzenie się światowego społeczeństwa. 

Jest procesem nieuniknionym, który posiada wady jaki zalety. Mająca wymiar gospodarczy społeczny, polityczny i kulturowy.

Intensywny rozwój globalizacji nastąpił wraz z rozwojem technologicznym oraz powstaniem organizacji międzynarodowych takich jak: 
	- Unia europejska
	- ONZ
	- NATO
	- Bank światowy
	- Międzynarodowy fundusz walutowy
	- Światowa organizacja handlu
	- Organizacje pozarządowe np. Amnesty Internationals

Zalety globalizacji:
	- rozwój cywilizacyjny
	- wzrost dobrobytu
	- znoszenie barier w przepływach ludności, dóbr, usług, kapitału
	- wymianę doświadczeń naukowych 
	- spadek kosztów produkcji
	- liberalizacja gospodarki
	- minimalizacja państw słabo rozwiniętych

Minusy globalizacji:
	- ograniczenia suwerenności państw
	- brak kontroli migracji
	- globalizacja problemów 
	- zanik tożsamości narodowych
	- rezygnacji z rozwoju kultury regionalnej na rzecz kultury masowej
	- zaostrzenie agresywnej konkurencji
	- cyberprzestępczość

Problemy globalne charakteryzują się:
	- globalnym wymiarem (ubóstwo, niedożywienie, zbrojenia)
	- złożonością
	- oddziaływaniem wielu czynników (transfer technologii, korupcja itp.)
	- konsekwencje globalne

Aby rozwiązać problemy globalne wymagana jest współpraca międzynarodowa.

![[Wykład 1 Bezpieczeństwo stosunków miedzynarodowych i systemu międzynarodowego.canvas]]

W XXI wieku pojawiły się nowe zagrożenia:
	- wojna jądrowa
	- degradacja środowiska
	- szybki przyrost ludności (głód)
	- problem wyżywienia ludzkości
	- dysproporcje rozwojowe państw
	- ograniczone zasoby naturalne (kończenie się zasobów)
	- terroryzm międzynarodowy i wewnętrzne zagrożenia bezpieczeństwa
	- cyberprzestępczość


# Wyzwania i problemy XXI wieku:

## Bezpieczeństwo międzynarodowe

Bezpieczeństwo systemu międzynarodowego możemy podzielić na:
 - polityczne, militarne, ekonomiczne, społeczne, **ekologiczne** (kryterium przedmiotowe)
 - naturalne, techniczne, strojowe, demograficzne, ideologiczne, gospodarcze, edukacyjne, psychologiczne, kulturowe (kryterium źródła zagrożenia)
 - światowe, międzynarodowe, państwowe, jednostki administracyjnej (kryterium skali zagrożeń)

Gwarantuje rozwój państw i społeczeństwa i składa się z:
 - zagrożeń zewnętrzne (inne państwa, zbrojenia, wojny)
 - wolności ekonomicznej
 - wolności społecznej 
 - wolności kulturowej
 - utrzymania pokoju

Negatywny wpływ na bezpieczeństwo międzynarodowe mają kryzysy ekonomiczne, finansowe, nierówności rozwojowe gospodarek państw, zadłużenie międzynarodowe oraz sankcje i restrykcje ekonomiczna nakładane na państwa. Poniżej kilka zagrożeń składających się na [[Wykład 1 - artukuł 1#Bezpieczeństwo międzynarodowe|Bezpieczeństwo międzynarodowe]]

### Dysproporcje rozwojowe
- dostęp do surowców (ropa, gaz ziemny)
- słaba pozycja międzynarodowa przez brak dostępu do surowców

**Rozwiązanie**
Współpraca i wzajemna integracja gospodarcza.

### Globalne kryzysy (np. finansowe)
- skutkiem zadłużenia międzynarodowego
- nadmierne zadłużenie nisko rozwiniętych państw

**Rozwiązania**
Powołanie takich organizacji jak Bank światowy, Międzynarodowy fundusz walutowy

### Zagrożenie militarne
- Wzrost siły militarnej powoduje automatyczne poczucie niebezpieczeństwa wśród pozostałych i prowadzi do nieustannego wyścigu zbrojeń.
- pomimo podpisania wielu układów rozbrojeniowych państwa posiadają arsenały broni różnego rodzaju (jądrowej też) pomimo redukcji broni atomowej
- handel bronią stanowi zagrożenie dla bezpieczeństwa narodowego

Broń jądrowa:
	Rosja – 7290, 
	USA – 7000, 
	Francja - 300, 
	Chiny – 260, 
	Wielka Brytania – 215, 
	Pakistan – 110-130, 
	Indie 110-120, 
	Izrael 80, 
	Korea Północna 10

### Terroryzm
Jedno z najpoważniejszych źródeł niebezpieczeństwa międzynarodowego

Powody
- nasilanie imigracji islamistów

Skutki
- ataki terrorystyczne na całym świecie w których ginie wiele osób


**Rozwiązanie:**
- ograniczenie migracji
- większa restrykcja na granicach

### Migracje
Powody:
- poprawa jakości życia
- wojny i konflikty zbrojne w rodzimych krajach

Skutki
- mieszanie się kultur
- brak zrozumienia kultur
- konflikty religijne i kulturowe
- konsekwencje polityczne związane z różnicą religii i kultur 

**Rozwiązanie:**
- ograniczenie migracji
- uświadamianie ludzi 

### Bezpieczeństwo/zagrożenie ekologiczne

Powody
- działalność człowieka
- zmiany klimatyczne: efekt cieplarniany, zanik warstw ozonowej, wyginięcia roślin i zwierząt, brak surowców naturalnych (nieodnawialnych) i degradacja środowiska naturalnego
- zanieczyszczenie środowiska, zmiany klimatyczne, biotechnologia, nadmierna eksploatacja surowców, zniszczenie różnorodności ekologicznej

Skutki
- brak dostępu do wody pitnej
- głód
- śmierć z głodu i braku wody
- choroby powodowane zanieczyszczeniami środowiska i wody 


**Rozwiązania:**
- ograniczenie wydobycia surowców 
- wdrożenie nowych technologii w dziedzinie odnawialnych źródeł energii np. dotację itp.
- oczyszczanie środowiska
- stworzenie nowych praw i regulacji ograniczających zanieczyszczenia środowiska

### Zagrożenia cybernetyczne
- polityczne motywowany atak lub groźba ataku na komputery, sieci i systemy informacyjne w celu zniszczenia infrastruktury oraz zastraszenia lub wymuszenia na rządzie i obywatelach daleko idących celów politycznych i społecznych.
  
**Rozwiązania:**
- podnoszenie świadomości ludzi
- wypracowanie i wdrożenie zmian prawnych i organizacyjnych, pozwalających na zapewnienie właściwego poziomu bezpieczeństwa cyberprzestrzeni i funkcjonujących w niej obywateli.


### Bezpieczeństwo ekonomiczna
W skład bezpieczeństwa ekonomicznego wchodzi bezpieczeństwo energetyczne

##### Bezpieczeństwo energetyczne:
- dostęp do gazu, ropy i innych surowców energetycznych
- szantaże ekonomiczne (powód brak surowców)
- brak surowców gazu i ropy

#### Problem żywności
Problem jest natury geograficznej i politycznej.

Powody
- zbyt duży przyrost ludności w stosunku do zdolności wytwórczych (Rolnictwo).
- spadek liczby zgonów (wzrostu długości życia)
- marnowanie żywności 

Skutki
- spore dysproporcje w spożyciu żywności na świecie. 
- 60% dzieci w Indiach głoduje, 55% dorosłych w USA ma nadwagę. (nie jest do dobre kryterium :)) - sposób odżywiania i nawyki są problemem w przypadku otyłości, a nie nadmiar żywności. Warto brać pod uwagę kaloryczność posiłków przeciętnego Amerykanina :).


**Rozwiązania**
- Dystrybucja pożywienia mogłaby częściowo rozwiązać ten problem.
- Wzrost produkcji może nie rozwiązać problemu(Może go rozwiązać częściowo)
- podstawę problemu stanowi ilość ludności, można ograniczyć przyrostu naturalny prawnie jak np. w Chinach maksymalnie 1 dziecko w małżeństwie


![[Globalizacja-i-problemy-globalne---konspekt--wykladu I,-maj-2020..docx]]

